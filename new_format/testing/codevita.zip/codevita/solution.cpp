#include <bits/stdc++.h>
using namespace std;
 
#define lli long long int
#define ll long long
#define li long int
#define ld long double
#define vi vector<int>
#define vs vector<string>
#define vll vector<long long>
#define vl vector<long>
#define vlli vector<long long int>
#define pii pair<int, int>
#define plli pair<lli, lli>
#define endl "\n"  
#define mod 1000000000+7

void file_input(){
    #ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    freopen("error.txt", "w", stderr);
    #endif 
return ;
}

int solve2(){
  int n, k;
  cin >> n >> k;

  vector<long long> arr(n);
  for (int i = 0; i < n; ++i)
  {
    cin >> arr[i];
  }
  sort(arr.begin(), arr.end());
  int count = 0;
  for(int i = 0; i < n; i++){
    if(i == 0){
      if(n > 0 and arr[i+1]-arr[i] <= k)
        count+=1;
    }
    else if(i == n-1){
      if(n > 0 and arr[i]-arr[i-1] <= k)
        count+=1;
    }
    else{
      if(abs(arr[i]-arr[i-1] <= k or abs(arr[i]-arr[i+1] <= k)))
        count+=1;
    }
  }
  return count;
}
int main(){
    clock_t start,end;
    start = clock();
    ios::sync_with_stdio(0);
    cin.tie(0);
    file_input();
    cout<<solve2();
    end = clock();
    cerr<<"time taken : "<<(double)(end-start)/CLOCKS_PER_SEC<<" secs"<<endl; 
    return 0;
}
